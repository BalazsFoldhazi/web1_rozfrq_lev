﻿<?php

$fomenu = array(
	'kezdolap' => array('fajl' => 'kezdolap', 'szoveg' => 'Kezdőlap'),
	'hirek' => array('fajl' => 'hirek', 'szoveg' => 'Hírek'),
    'csapat' => array('fajl' => 'csapat', 'szoveg' => 'Csapat'),   
	'videok' => array('fajl' => 'videok', 'szoveg' => 'Videók'),    
	'kepek' => array('fajl' => 'kepek', 'szoveg' => 'Képek'),
    'kapcsolat' => array('fajl' => 'kapcsolat', 'szoveg' => 'Kapcsolat'),
	'bejelentkezes' => array('fajl' => 'bejelentkezes', 'szoveg' => 'Bejelentkezés'),
    'kijelentkezes' => array('fajl' => 'kijelentkezes', 'szoveg' => 'Kijelentkezés'),	
    'regisztracio' => array('fajl' => 'regisztracio', 'szoveg' => 'Regisztráció'),
);

$hiba_oldal = array ('fajl' => '404', 'szoveg' => 'A keresett oldal nem található');

?>