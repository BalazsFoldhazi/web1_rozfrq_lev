<h2>Videók</h2>
<br>
<h3>Youtube</h3>
<div class="videok">
	<iframe width="560" height="315" src="https://youtube.com/embed/tQZHinloy9Q" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
</div>
<br>
<h3>Beágyazott FTP-ről</h3>
<div class="videok">
	<video width="426" height="240" poster="./kepek/logo.png" id="player" playsinline controls>
		<source src="./videok/bekescsaba.mp4" type="video/mp4">		
	</video>
</div>