
<br>
<p class="entry"><span class="kiemelt">HÍREK</p>
<p class="entry"><span class="kiemelt">Sorsolás, naptár, kapcsolat </p>
<br>
<p>2017. 11. 02., Hírek</p>
<br>
<br>

<table>
			<thead>
				<tr>
				<th style="width: 200px; height: 50px; color: white; background: red;">Tabella-Menetrend</th>
				<th style="width: 200px; height: 50px; color: white; background: red;">Naptár</th>
					<th style="width: 200px; height: 50px; color: white; background: red;">Kapcsolat</th>
				</tr>
			</thead>
</table>
