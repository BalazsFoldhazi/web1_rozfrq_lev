<h2>Képek</h2>
	
	<?php include("oldal/kepek_feltolt.php");?>
		
	<?php include("oldal/kepek_megjelenit.php");?>
	