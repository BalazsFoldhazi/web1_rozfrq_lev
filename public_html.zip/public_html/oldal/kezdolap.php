<img style="width:100%;" id="slide" src="./kepek/slide.jpg" title="Slide" alt="Slide">
<br>
<p style="background-color: purple; color: white;" class="entry">Ez a weboldal a Neuman János Egyetem Üzemmérnökinformatikus BPROF levelezős képzés 4.félévében oktatott Webprogramozás1 című tárgy beadandó feladata!<br>
Hivatalos oldal: <a style="color: red;"href="http://elorenkse.hu/site/" target="_blank">IDE</a> kattint érhető el!</p>
<br>
<p class="entry"><span class="kiemelt">Sorsolás, naptár, kapcsolat </p>
<br>
<p>2017. 11. 02., Hírek</p>
<br>
<br>

<table>
			<thead>
				<tr>
				<th style="width: 200px; height: 50px; color: white; background: red;">Tabella-Menetrend</th>
				<th style="width: 200px; height: 50px; color: white; background: red;">Naptár</th>
					<th style="width: 200px; height: 50px; color: white; background: red;">Kapcsolat</th>
				</tr>
			</thead>
</table>
<br>
<p class="entry"><span class="kiemelt">A Kozármisleny ellen már az első osztály a tét</p>

<p class="entry">Interjú Papp Bálint vezetőedzővel

Szombaton délután ismét női kézilabdától lesz hangos a Békéscsabai Városi Sportcsarnok, hiszen lila-fehér együttesünk ebben a bajnoki kiírásban az utolsó előtti hazai összecsapásán lép parkettra. Az ellenfél pedig az a Kozármisleny gárdája lesz, akik már egyszer itt a rájátszásban kibabráltak lányainkkal, amivel megszakították az Előre 21 mérkőzésen át tartó veretlenségi sorozatát. De ami még ennél is fontosabb, már csak kettő pont kell csapatunknak ahhoz, hogy ismét első osztályú tagságot ünnepelhessen. A kiemelt fontossággal bíró mérkőzés előtt együttesünk vezetőedzőjével Papp Bálinttal beszélgettem.<br>
<img style="width: 80%;" id="pbalint" src="./kepek/pbalint.jpg" title="edzo" alt="edzoba">

<p class="entry">– Túl vagytok egy kisebb szüneten már ami a mérkőzéseket illeti, mivel telt a csapat életében ez a két hét?

– Próbáltuk tartani a megszokott ütemet, hogy ne törjön meg a lendület, bár húsvétkor azért egy picit szusszanhattak a lányok, de alapjában véve azt a munkát végeztük el, amit általában szoktunk két találkozó között. Kukely Annát és Bucsi Lilit ugyan válogatott kötelezettségük miatt kénytelenek voltunk néhány napra nélkülözni, ahogy nyilván sérültjeinket is, de összeségében elvégeztünk mindent amit szerettem volna. Ha már a sérülteknél tartunk, az mindenképpen jó hír, hogy Giricz Laura már egész héten a csapattal tudott edzeni, viszont a szombati játéka még azért kérdéses, erről a végső szót majd csak a találkozó előtt az egészségügyi stáb mondja ki.

– Tagadhatatlanul jelentős állomáshoz érkeztetek, úgyis fogalmazhatnék, hogy már kinyitottátok az NB1 kapuját, szombaton csak be kell lépni rajta…

– Valóban ilyen szempontból is ez most tényleg egy roppant fontos összecsapás lesz, hiszen amiért küzdöttünk egész évben, azt mindössze egy győzelemmel elérhetjük. Nyilván érződik is ez a lányokon, nem kell külön motiválni senkit sem, mindenki tisztában van azzal mi a tétje a szombati találkozónak. Ettől függetlenül azt gondolom, túlmisztifikálni sem szabad a mérkőzést, úgy kell kezelni mint bármelyik másik rájátszás találkozót és leginkább magunkra koncentrálni, illetve arra, hogy a játékunkat a legtökéletesebben a pályára tudjuk vinni. Egyelőre nem is gondolkodunk a hétvégénél tovább, csak a mostani feladatra fókuszálunk, azaz annak a két pontnak a megszerzésére ami elválaszt minket a legmagasabb osztálytól.

– Szombati ellenfeleteknek kétségtelenül van miért visszavágni, mennyire van még a revans vágya is a fejetekben?

– Nézd, egy nagyon kellemetlen vereséget szenvedtünk el Kozármislenyben, szóval hazudnék ha azt mondanám, hogy nem buzog bennünk a visszavágás. Kifejezetten rosszul sikerült mérkőzés volt az a számunkra, ahol bár jól kezdtünk, de kulcs szituációkban belehibáztunk, ami egyre inkább elbizonytalanított minket. Ennek hatására belekerültünk egy olyan spirálba, amiből akkor nem volt visszaút és simán kikaptunk. Persze, nem akarom elvenni ellenfelünktől sem az érdemet, hiszen kihasználták a lehetőséget és remekül játszottak azon az estén. Ebből is látszik, hogy jó csapattal állunk szemben, ezt testközelből is megtapasztalhattuk. Változatos játékkal, sok cserével kézilabdáznak, de ezt tehetik is, hiszen két közel azonos soruk van, ráadásul védekezésben is agresszívan, határozottan teszik a dolgukat. Meglehetősen sok kellemetlenséget is okoztak nekünk akkor támadásban azzal, hogy feljebb tolták a védőiket, úgyhogy erre most mindenképpen meg kell találnunk az ellenszert.

– Abból az összecsapásból kiindulva ezúttal sem számíthatunk könnyű derbire?

– Nehéz előre megjósolni, mert itt a másodosztályban aztán tényleg minden meccs más, de az biztos, hogy ha nyerni akarunk, a kozármislenyi találkozóhoz képest a játék minden elemében javulnunk kell. Támadásban magabiztosabbnak kell lennünk és belőnünk a ziccereket, hátul pedig sokkal agresszívabbnak lenni és bizony a kapuból is kell a jó teljesítmény. A kulcs azonban most is az lesz, mennyire tudjuk dominálni a játékot és gyors indításokkal apellálni, mert legutóbb ez nagyon hiányzott. Valamint okosabb, türelmesebb játékot várok a lányaimtól, főleg a kapusukkal szemben, aki azért egy sokat tapasztalt rutinos portás, tehát vele szemben is koncentrált, higgadt megoldások kellenek majd. Összességében egy látványos, élvezetes találkozóra számítok, remek hangulattal fűszerezve és persze győzelemre, mert az nem kérdés, hogy itt hazai környezetben szeretnénk megszerezni a feljutást jelentő két pontot.

Dömény Dezső

</p>