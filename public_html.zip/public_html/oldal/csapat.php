<h2>CSAPAT 2021-2022</h2>
<br>
<h3>Békéscsaba ELŐRE NKSE csapata -2021/2022.</h3>
<br>

 
		<table>
			<thead>
				<tr>
				<th style="width: 500px;">Kép</th>
				<th style="width: 500px; text-align: center;">Név</th>
				<th style="width: 500px; text-align: center;">Poszt</th>
				<th style="width: 500px; text-align: center;">Kor</th>
				</tr>
			</thead>
			<tbody>
			    <tr>
			        <td style="width: 300px; text-align: center;"><a href="http://elorenkse.hu/site/player/androczki-flora/"><img width="90" height="90" src="./kepek/08_androczki_flora_2021_2022-90x90.jpg" class="attachment-player_thumbnail wp-post-image" alt="08_androczki_flora_2021_2022"></a>
			        </td>
			       <td style="width: 200px; text-align: center;">Kiss Anita </td>
			        <td  style="width: 200px; text-align: center;">szélső </td>
			        <td  style="width: 200px; text-align: center;">20</td>
			     </tr>
			     	    <tr>
			        <td style="width: 300px; text-align: center;"><a href="http://elorenkse.hu/site/player/androczki-flora/"><img width="90" height="90" src="./kepek/08_androczki_flora_2021_2022-90x90.jpg" class="attachment-player_thumbnail wp-post-image" alt="08_androczki_flora_2021_2022"></a>
			        </td>
			       <td style="width: 200px; text-align: center;">Kiss Anita </td>
			        <td  style="width: 200px; text-align: center;">szélső </td>
			        <td  style="width: 200px; text-align: center;">20</td>
			     </tr>
			     	    <tr>
			        <td style="width: 300px; text-align: center;"><a href="http://elorenkse.hu/site/player/androczki-flora/"><img width="90" height="90" src="./kepek/08_androczki_flora_2021_2022-90x90.jpg" class="attachment-player_thumbnail wp-post-image" alt="08_androczki_flora_2021_2022"></a>
			        </td>
			       <td style="width: 200px; text-align: center;">Kiss Anita </td>
			        <td  style="width: 200px; text-align: center;">szélső </td>
			        <td  style="width: 200px; text-align: center;">20</td>
			     </tr>
			     	    <tr>
			        <td style="width: 300px; text-align: center;"><a href="http://elorenkse.hu/site/player/androczki-flora/"><img width="90" height="90" src="./kepek/08_androczki_flora_2021_2022-90x90.jpg" class="attachment-player_thumbnail wp-post-image" alt="08_androczki_flora_2021_2022"></a>
			        </td>
			       <td style="width: 200px; text-align: center;">Kiss Anita </td>
			        <td  style="width: 200px; text-align: center;">szélső </td>
			        <td  style="width: 200px; text-align: center;">20</td>
			     </tr>
			     	    <tr>
			        <td style="width: 300px; text-align: center;"><a href="http://elorenkse.hu/site/player/androczki-flora/"><img width="90" height="90" src="./kepek/08_androczki_flora_2021_2022-90x90.jpg" class="attachment-player_thumbnail wp-post-image" alt="08_androczki_flora_2021_2022"></a>
			        </td>
			       <td style="width: 200px; text-align: center;">Kiss Anita </td>
			        <td  style="width: 200px; text-align: center;">szélső </td>
			        <td  style="width: 200px; text-align: center;">20</td>
			     </tr>
			     	    <tr>
			        <td style="width: 300px; text-align: center;"><a href="http://elorenkse.hu/site/player/androczki-flora/"><img width="90" height="90" src="./kepek/08_androczki_flora_2021_2022-90x90.jpg" class="attachment-player_thumbnail wp-post-image" alt="08_androczki_flora_2021_2022"></a>
			        </td>
			       <td style="width: 200px; text-align: center;">Kiss Anita </td>
			        <td  style="width: 200px; text-align: center;">szélső </td>
			        <td  style="width: 200px; text-align: center;">20</td>
			     </tr>
			 </tbody>
		</table>
		


