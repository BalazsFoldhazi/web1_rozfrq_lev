﻿<?php
echo"
	\t<footer>
	\t\t<h3>Készítette: Földházi Balázs rozfrq</h3>
	\t</footer>
	";
?>
